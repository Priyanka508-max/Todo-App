import React, { useState } from "react";
import { Modal, Button, Input, Select, DatePicker } from "antd";

const { TextArea } = Input;
const { Option } = Select;

const TaskModal = ({ visible, onCancel, onSave, task }) => {
    return (
        <Modal
            title={task ? "Edit Task" : "New Task"}
            visible={visible}
            onCancel={onCancel}
            footer={null}
        >
            <div className="space-y-4">
                <div className="flex space-x-4">
                    <div className="w-1/2">
                        <label className="block mb-2">Assigned To *</label>
                        <Select defaultValue={task ? task.user : "User 1"} className="w-full">
                            <Option value="User 1">User 1</Option>
                            <Option value="User 2">User 2</Option>
                            <Option value="User 3">User 3</Option>
                            <Option value="User 4">User 4</Option>
                        </Select>
                    </div>
                    <div className="w-1/2">
                        <label className="block mb-2">Status *</label>
                        <Select defaultValue={task ? task.status : "Not Started"} className="w-full">
                            <Option value="Not Started">Not Started</Option>
                            <Option value="In Progress">In Progress</Option>
                            <Option value="Completed">Completed</Option>
                        </Select>
                    </div>
                </div>

                <div className="flex space-x-4">
                    <div className="w-1/2">
                        <label className="block mb-2">Due Date</label>
                        <DatePicker className="w-full" defaultValue={task ? task.dueDate : null} />
                    </div>
                    <div className="w-1/2">
                        <label className="block mb-2">Priority *</label>
                        <Select defaultValue={task ? task.priority : "Normal"} className="w-full">
                            <Option value="Low">Low</Option>
                            <Option value="Normal">Normal</Option>
                            <Option value="High">High</Option>
                        </Select>
                    </div>
                </div>

                <div>
                    <label className="block mb-2">Description</label>
                    <TextArea rows={4} defaultValue={task ? task.comments : ""} />
                </div>

                <div className="flex justify-end space-x-2">
                    <Button onClick={onCancel} className="bg-yellow-500">
                        Cancel
                    </Button>
                    <Button onClick={onSave} type="primary" className="bg-green-500">
                        Save
                    </Button>
                </div>
            </div>
        </Modal>
    );
};

const TaskTable = () => {
    const [tasks, setTasks] = useState([
        { user: "User 1", status: "Completed", dueDate: "12/10/2024", priority: "Low", comments: "This task is good" },
        { user: "User 2", status: "In Progress", dueDate: "14/09/2024", priority: "High", comments: "This task is good" },
    ]);

    const [isModalVisible, setIsModalVisible] = useState(false);
    const [currentTask, setCurrentTask] = useState(null);

    const showModal = (task = null) => {
        setCurrentTask(task);
        setIsModalVisible(true);
    };

    const hideModal = () => {
        setIsModalVisible(false);
        setCurrentTask(null);
    };

    const saveTask = () => {
        // Logic for saving/updating task
        hideModal();
    };

    return (
        <div className="p-4">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-bold">Tasks</h2>
                <div className="space-x-2">
                    <Button onClick={() => showModal()} className="bg-yellow-500 text-white">
                        New Task
                    </Button>
                    <Button className="bg-yellow-500 text-white">Refresh</Button>
                </div>
            </div>

            {/* Task Table */}
            <table className="min-w-full bg-white border rounded">
                <thead>
                    <tr className="bg-gray-100 border-b">
                        <th className="p-3 text-left">Assigned To</th>
                        <th className="p-3 text-left">Status</th>
                        <th className="p-3 text-left">Due Date</th>
                        <th className="p-3 text-left">Priority</th>
                        <th className="p-3 text-left">Comments</th>
                        <th className="p-3 text-left">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {tasks.map((task, index) => (
                        <tr key={index} className="border-b">
                            <td className="p-3">{task.user}</td>
                            <td className="p-3">{task.status}</td>
                            <td className="p-3">{task.dueDate}</td>
                            <td className="p-3">{task.priority}</td>
                            <td className="p-3">{task.comments}</td>
                            <td className="p-3">
                                <Button onClick={() => showModal(task)}>Edit</Button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {/* Task Modal */}
            <TaskModal
                visible={isModalVisible}
                onCancel={hideModal}
                onSave={saveTask}
                task={currentTask}
            />
        </div>
    );
};

export default TaskTable;
