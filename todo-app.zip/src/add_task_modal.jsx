import { useState } from 'react';
import { Modal, Button, } from 'antd';
import useTodoStore from './todoStore';

const AddTaskModal = ({ isModalOpen, setIsModalOpen }) => {
    const addTodo = useTodoStore((state) => state.addTodo);
    const [assignedTo, setAssignedTo] = useState('');
    const [status, setStatus] = useState('Not Started');
    const [dueDate, setDueDate] = useState('');
    const [priority, setPriority] = useState('Normal');
    const [comments, setComments] = useState('');

    const handleAddTodo = () => {
        addTodo({
            id: Math.random(),
            assignedTo,
            status,
            dueDate,
            priority,
            comments,
        });
        setIsModalOpen(false);
    };

    return (
        <Modal
            title="New Task"
            open={isModalOpen}
            onCancel={() => setIsModalOpen(false)}
            footer={[
                <Button key="cancel" onClick={() => setIsModalOpen(false)}>
                    Cancel
                </Button>,
                <Button key="save" type="primary" onClick={handleAddTodo}>
                    Add Task
                </Button>,
            ]}
        >
            {/* Add form inputs here similar to EditTaskModal */}
        </Modal>
    );
};

export default AddTaskModal;
