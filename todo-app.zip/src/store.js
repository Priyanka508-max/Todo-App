import create from 'zustand';

// Zustand store for managing todos
const useTodoStore = create((set) => ({
    todos: [
        {
            id: 1,
            assignedTo: 'User 1',
            status: 'Completed',
            dueDate: '12/10/2024',
            priority: 'Low',
            comments: 'This task is good',
        },
        {
            id: 2,
            assignedTo: 'User 2',
            status: 'In Progress',
            dueDate: '14/09/2024',
            priority: 'High',
            comments: 'This task is important',
        },
    ],
    addTodo: (todo) => set((state) => ({ todos: [...state.todos, todo] })),
    editTodo: (id, updatedTodo) =>
        set((state) => ({
            todos: state.todos.map((todo) =>
                todo.id === id ? { ...todo, ...updatedTodo } : todo
            ),
        })),
    deleteTodo: (id) =>
        set((state) => ({ todos: state.todos.filter((todo) => todo.id !== id) })),
}));


export default useTodoStore;