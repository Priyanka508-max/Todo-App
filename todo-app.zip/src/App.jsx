import TaskTable from './task_table'
import TodoApp from './todo_app';

function App() {

  return (
    <div className=''>
      <TodoApp />
      <TaskTable />
    </div>
  )
}

export default App
