import React, { useState } from 'react';
import { Modal, Button, Input, Select, DatePicker } from 'antd';

const { Option } = Select;

const EditTaskModal = ({ todo, isModalOpen, setIsModalOpen, onSubmit }) => {
    const [assignedTo, setAssignedTo] = useState(todo.assignedTo);
    const [status, setStatus] = useState(todo.status);
    const [dueDate, setDueDate] = useState(todo.dueDate);
    const [priority, setPriority] = useState(todo.priority);
    const [comments, setComments] = useState(todo.comments);

    const handleSave = () => {
        onSubmit({ assignedTo, status, dueDate, priority, comments });
    };

    return (
        <Modal
            title="Edit Task"
            open={isModalOpen}
            onCancel={() => setIsModalOpen(false)}
            footer={[
                <Button key="cancel" onClick={() => setIsModalOpen(false)}>
                    Cancel
                </Button>,
                <Button key="save" type="primary" onClick={handleSave}>
                    Save
                </Button>,
            ]}
        >
            <div className="space-y-4">
                <div>
                    <label>Assigned To</label>
                    <Input value={assignedTo} onChange={(e) => setAssignedTo(e.target.value)} />
                </div>
                <div>
                    <label>Status</label>
                    <Select value={status} onChange={(value) => setStatus(value)} style={{ width: '100%' }}>
                        <Option value="Not Started">Not Started</Option>
                        <Option value="In Progress">In Progress</Option>
                        <Option value="Completed">Completed</Option>
                    </Select>
                </div>
                <div>
                    <label>Due Date</label>
                    <DatePicker value={dueDate} onChange={(date, dateString) => setDueDate(dateString)} />
                </div>
                <div>
                    <label>Priority</label>
                    <Select value={priority} onChange={(value) => setPriority(value)} style={{ width: '100%' }}>
                        <Option value="Low">Low</Option>
                        <Option value="Normal">Normal</Option>
                        <Option value="High">High</Option>
                    </Select>
                </div>
                <div>
                    <label>Comments</label>
                    <Input.TextArea value={comments} onChange={(e) => setComments(e.target.value)} />
                </div>
            </div>
        </Modal>
    );
};

export default EditTaskModal;
