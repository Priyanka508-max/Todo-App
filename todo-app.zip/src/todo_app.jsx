import { useState } from 'react';
import { Button } from 'antd';
import EditTaskModal from './edit_task_modal';
import useTodoStore from './store';

const TodoApp = () => {
    const { todos, deleteTodo, editTodo } = useTodoStore();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingTodo, setEditingTodo] = useState(null);

    const openEditModal = (todo) => {
        setEditingTodo(todo);
        setIsModalOpen(true);
    };

    const handleDelete = (id) => {
        deleteTodo(id);
    };

    const handleEditSubmit = (updatedTodo) => {
        editTodo(editingTodo.id, updatedTodo);
        setIsModalOpen(false);
    };

    return (
        <div className="p-4">
            <table className="text-black min-w-full bg-white border-collapse">
                <thead>
                    <tr>
                        <th className="border px-4 py-2">Assigned To</th>
                        <th className="border px-4 py-2">Status</th>
                        <th className="border px-4 py-2">Due Date</th>
                        <th className="border px-4 py-2">Priority</th>
                        <th className="border px-4 py-2">Comments</th>
                        <th className="border px-4 py-2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {todos.map((todo) => (
                        <tr key={todo.id}>
                            <td className="border px-4 py-2">{todo.assignedTo}</td>
                            <td className="border px-4 py-2">{todo.status}</td>
                            <td className="border px-4 py-2">{todo.dueDate}</td>
                            <td className="border px-4 py-2">{todo.priority}</td>
                            <td className="border px-4 py-2">{todo.comments}</td>
                            <td className="border px-4 py-2">
                                <Button onClick={() => openEditModal(todo)}>Edit</Button>
                                <Button onClick={() => handleDelete(todo.id)} danger>
                                    Delete
                                </Button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {editingTodo && (
                <EditTaskModal
                    todo={editingTodo}
                    isModalOpen={isModalOpen}
                    setIsModalOpen={setIsModalOpen}
                    onSubmit={handleEditSubmit}
                />
            )}
        </div>
    );
};

export default TodoApp;